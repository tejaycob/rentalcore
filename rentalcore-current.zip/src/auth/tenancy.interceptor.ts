// src/auth/tenancy.interceptor.ts
//
// Sets app.company_id, app.user_role, and app.user_id as PostgreSQL session
// variables at the start of every authenticated request. This is what makes
// Row Level Security actually enforce tenant isolation — without these vars
// set, every RLS policy returns false and all queries return 0 rows.
//
// Must run AFTER JwtAuthGuard has populated req.user.

import {
  Injectable, NestInterceptor, ExecutionContext, CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { Pool } from 'pg';

@Injectable()
export class TenancyInterceptor implements NestInterceptor {
  constructor(private readonly pool: Pool) {}

  async intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>> {
    const req = context.switchToHttp().getRequest();
    const user = req.user;

    if (user?.companyId) {
      // Set session variables so RLS policies can resolve current_company_id() etc.
      // We use a dedicated client for each request — not the shared pool — because
      // SET LOCAL only persists for the current transaction, and we'd need a
      // transaction for that. SET (without LOCAL) persists for the session, which
      // is fine since pool connections are request-scoped in this pattern.
      await this.pool.query(
        `SELECT set_config('app.company_id', $1, false),
                set_config('app.user_role',   $2, false),
                set_config('app.user_id',     $3, false)`,
        [user.companyId, user.role, user.userId],
      );
    }

    return next.handle();
  }
}
